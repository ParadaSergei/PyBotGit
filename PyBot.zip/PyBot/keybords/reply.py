from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, KeyboardButtonPollType
from aiogram.utils.keyboard import ReplyKeyboardBuilder

# start_kb = ReplyKeyboardMarkup(
#     keyboard=
#     [
#         [
#             KeyboardButton(text="Посмотреть меню"),
#             KeyboardButton(text="О магазине"),
#         ],
#         [
#             KeyboardButton(text="Выбрать доставку"),
#             KeyboardButton(text="Выбрать оплату"),
#         ],
#     ],
#     resize_keyboard=True,
#     input_field_placeholder='Что вас интересует?'
# )

start_kb2Markup = ReplyKeyboardMarkup(
     keyboard =
     [
        [
            KeyboardButton(text="О меню"),
            KeyboardButton(text="О магазине"),
        ],
        [
             KeyboardButton(text="Выбрать доставку"),
             KeyboardButton(text="Выбрать оплату"),
        ],

    ],
    resize_keyboard=True,
    input_field_placeholder='Что вас интересует?'
)

# start_kb2 = ReplyKeyboardBuilder()
# start_kb2.add(
#     KeyboardButton(text="О меню"),
#     KeyboardButton(text="О магазине"),
#     KeyboardButton(text="Выбрать оплату"),
#     KeyboardButton(text="Выбрать доставку",),
# )
# start_kb2.adjust(2,2)

# start_kb3 = ReplyKeyboardBuilder()
# start_kb3.attach(start_kb2)
# start_kb3.row(KeyboardButton(text="Оставить отзыв"),)


contact_kb = ReplyKeyboardBuilder()
contact_kb.add(
        KeyboardButton(text="Создать опрос", request_poll=KeyboardButtonPollType()),
        KeyboardButton(text="Предостваить контакт 🤔", request_contact=True),
        KeyboardButton(text="Предоставить геолокацию", request_location=True),

)
contact_kb.adjust(1,2)


