from string import punctuation
from aiogram import types , Router ,F
from aiogram.filters import CommandStart

from filters.chat_types import ChatTypeFilter

user_group_router = Router()
user_group_router.message.filter(ChatTypeFilter(['group' , 'supergroup']))



restriced_world = {'кабан', 'хомяк', 'выхухоль'}

def clear_text(text: str):
    return text.translate(str.maketrans(' ', ' ', punctuation))

@user_group_router.edited_message()
@user_group_router.message()
async def cleaner(message: types.Message):
    if restriced_world.intersection(clear_text(message.text.lower()).split()): #split () передает это в список
        await message.answer(f"{message.from_user.first_name}, Соблюдайте порядок в чате!")
        await message.delete()