
from aiogram import types , Router ,F
from aiogram.enums.parse_mode import ParseMode
from aiogram.filters import CommandStart, Command, or_f
from aiogram.utils.formatting import as_list, as_marked_section, Bold
from filters.chat_types import ChatTypeFilter

from keybords import reply


user_private_router = Router()
user_private_router.message.filter(ChatTypeFilter(['private']))


@user_private_router.message(CommandStart())
async def start_cmd(message: types.Message):
    await message.answer('Привет, я виртуальный помощник',
                         reply_markup=reply.start_kb2Markup)


@user_private_router.message(or_f(Command('menu')))
@user_private_router.message(F.text.lower() == "о меню")
#@user_private_router.message(Command('menu'))
async def cmd_menu(message: types.Message):
    await message.answer("Вот меню")


@user_private_router.message(or_f(Command('about') ,(F.text.lower() == "о магазине")))
async def cmd_about(message: types.Message):
    await message.answer("О магазине")


#@user_private_router.message(or_f(Command('payment'), ( F.text.lower() == "Выбрать оплату") ))
@user_private_router.message(Command('payment'))
@user_private_router.message(F.text.lower() == "выбрать оплату")
async def cmd_payment(message: types.Message):
    text = as_marked_section(
        Bold("Выбрать оплату"),
        "Картой бота",
        "При получения карта/кэш",
        "В заведении",
        marker='✅',
    )
    await message.answer(text.as_html(),parse_mode="HTML")


@user_private_router.message(or_f(Command('shipping'),(F.text.lower() == "выбрать доставку")))
async def cmd_shipping(message: types.Message):
    text = as_list(
    as_marked_section(
        Bold("Выбрать доставку"),
        "Курьер",
        "Самовывоз",
        marker='✅',
    ),
        as_marked_section(
            Bold("Нельзя"),
            "Почтой",
            "Голуби",
            marker='❌'
        ),
        sep='\n------------------\n'
    )
    await message.answer(text.as_html(),parse_mode="HTML")


@user_private_router.message(F.text.lower().contains('ес'))
async def cmd_text(message: types.Message):
    await message.answer("Это магический фильтр 2")


@user_private_router.message(F.contact)
async def cmd_contains(message: types.Message):
    await message.answer("Телефон принят, мы вам позвоним")

    #await message.answer(str(message.contact))

    @user_private_router.message(F.location)
    async def cmd_contains(message: types.Message):
        await message.answer("Геолокация принята, ожидайте заказ")
    #  await message.answer(str(message.location))
