from aiogram.types import BotCommand

private = [
    BotCommand(command="menu" , description="О меню"),
    BotCommand(command="about", description="О магазине"),
    BotCommand(command="payment", description="Выбрать оплату"),
    BotCommand(command="shipping", description="Выбрать доставку")
]